# Applied-AI-ML-Assignments
Assignments from Applied AI ML Course
